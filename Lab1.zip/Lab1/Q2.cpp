//****************************************************************************************
// Q2:
//****************************************************************************************


#include <iostream>
using namespace std;

int Found(int array[], int size, int num);

int main()
{
	int Size;
	int integer;
	int Num;
	
	cout << "This Program Get the Input Array and then an Integer to Find in the Array\n\n";
	cout << "NOTE: If the Integer is Not Found It will Give -1...\n";
	cout << "Enter the size of the Array: ";
	cin >> Size;

	int Array[Size];
	cout << "Enter the numbers in the Array: ";
	for (int i = 0; i < Size; i++)
	{
		cin >> Array[i];
	}

	cout << "Your Entered Array:\n";
	for (int i = 0; i < Size; i++)
	{
		cout << Array[i] << endl;
	}

	cout << "Enter the integer to find in the Array: ";
	cin >> integer;

	Num = Found(Array, Size, integer);

	cout << "Answer: " << Num << endl;

	return 0;
}


int Found(int array[], int size, int num)
{
	int temp;
	for (int i = 0; i < size; i++)
	{
		if (array[i] == num)
		{
			temp = i;
			break;
		}
		else
		{
			temp = -1;
		}
	}
	return temp;
}
