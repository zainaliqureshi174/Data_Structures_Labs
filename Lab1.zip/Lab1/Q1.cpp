//============================================================================
// Name        : Lab1.cpp
// Author      : Muhammad Zain Ali
// Topic : Arrays in C++
//============================================================================

//****************************************************************************************
//Q1
//****************************************************************************************

#include <iostream>
using namespace std;

int main()
{
	int Size;
	int Temp;
	cout << "This Program Changes the Odd numbers of the Array to thier Cubes,\n";
	cout << "And Even Numbers to their Squares.\n\n";
	cout << "Enter the size of the Array: ";
	cin >> Size;

	int Array[Size];
	cout << "Enter the numbers in the Array: ";
	for (int i = 0; i < Size; i++)
	{
		cin >> Array[i];
	}

	cout << "Your Entered Array:\n";
	for (int i = 0; i < Size; i++)
	{
		cout << Array[i] << endl;
	}

	for (int i = 0; i < Size; i++)
	{
		if (Array[i]%2 == 0)
		{
			Temp = Array[i]*Array[i];
			Array[i] = Temp;
		}
		else
		{
			Temp = Array[i]*Array[i]*Array[i];
			Array[i] = Temp;
		}
	}

	cout << "Your Modified Array:\n";
	for (int i = 0; i < Size; i++)
	{
		cout << Array[i] << endl;
	}
		return 0;
}
