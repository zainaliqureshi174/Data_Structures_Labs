#include <iostream>
using namespace std;


struct Person
{
	string Name;
	int Age;
	string City;
};

int main()
{

	cout << "This Program Stores and Print The 4 Person Attributes by using Structures\n\n";
	Person Array[4];
	Array[0] = {"Zain", 18, "Malakwal"};
	Array[1] = {"Abdullah", 20, "Islamabad"};
	Array[2] = {"Bilal", 25, "Pindi"};
	Array[3] = {"Asad", 21, "Pindi"};

	cout << "Here are the Persons: \n\n";
	for (int i = 0; i < 4; i++)
	{
		cout << "Name: " << Array[i].Name << endl;
		cout << "Age: " <<  Array[i].Age << endl;
		cout << "City: " <<  Array[i].City << endl;
		cout << endl;
	}
	
	return 0;
}
