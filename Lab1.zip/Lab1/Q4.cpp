//****************************************************************************************
// Q4:
//****************************************************************************************
#include <iostream>
using namespace std;

int main()
{
	int Size;
	cout << "Enter the size of the Array: ";
	cin >> Size;

	int Array[Size];
	cout << "Enter the numbers in the Array: ";
	for (int i = 0; i < Size; i++)
	{
		cin >> Array[i];
	}

	int Leader[Size];
	int leader = 1;
	int rightmost = Array[Size-1];
	
	cout << "Your Entered Array:\n";
	for (int i = 0; i < Size; i++)
	{
		cout << Array[i] << " ";
	}

	cout << endl;
	
	Leader[0] = rightmost;
	for (int i = Size-2; i >= 0; i--)
	{
		if (Array[i] > rightmost)
		{
			rightmost = Array[i];
			Leader[leader++] = rightmost;
		}
	}

	for (int i = leader-1; i >= 0; i--)
	{
		cout << Leader[i] << " ";
	}
	
	cout << endl;
	return 0;
}

