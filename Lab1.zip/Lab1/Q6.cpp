//****************************************************************************************
//Q6
//****************************************************************************************
#include <iostream>
using namespace std;

void intersection(int num, int arr[], int size)
{
	for (int i = 0; i < size; i++)
	{
		if (arr[i] == num)
		{
			cout << num << endl;
			break;
		}
	}
} 

int main()
{
	int Size1;
	int Size2;
	
	cout << "Enter the size of the Array 1: ";
	cin >> Size1;

	int Array1[Size1];
	cout << "Enter the numbers in the Array 1: ";
	for (int i = 0; i < Size1; i++)
	{
		cin >> Array1[i];
	}
	
	cout << "Your Entered Array: ";
	for (int i = 0; i < Size1; i++)
	{
		cout << Array1[i] << " ";
	}
	
	cout << endl;
	
	
	cout << "Enter the size of the Array 2: ";
	cin >> Size2;

	int Array2[Size2];
	cout << "Enter the numbers in the Array 2: ";
	for (int i = 0; i < Size2; i++)
	{
		cin >> Array2[i];
	}
	
	cout << "Your Entered Array: ";
	for (int i = 0; i < Size2; i++)
	{
		cout << Array2[i] << " ";
	}
	
	cout << endl;
	
	bool Go = true;
	for (int i = 0; i < Size1; i++)
	{
		if (i == 0)
		{
			intersection(Array1[i], Array2, Size2);
		}
		
		else if (i > 0)
		{
			for (int l = i; l > 0; l--)
			{
				if (Array1[i] != Array1[l - 1])
				{
					Go = true;
				}
				else 
				{
					Go = false;
					break;
				}
			}
			
			if (Go)
			{
				intersection(Array1[i], Array2, Size2);
			}
		}
	}
	return 0;
}
