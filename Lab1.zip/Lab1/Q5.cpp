//****************************************************************************************
//Q5
//****************************************************************************************
#include <iostream>
using namespace std;

int main()
{
	int Array[11] = {10, 12, 20, 30, 25, 40, 32, 31, 35, 50, 60};
	int array[6];
	int j = 0;

	cout << "Your Array is:\n";
	for (int i = 0; i < 11; i++)
	{
		cout << Array[i] << endl;
	}

	for (int i = 0; i < 11; i++)
	{
		if (i >= 3 && i <= 8)
		{
			array[j] = Array[i];
			j++;
		}
	}

	cout << "Subarray between indexes 3 and 8:\n";
	cout << "\n\nYour subarray is:\n";
	for (int i = 0; i < 6; i++)
	{
		cout << array[i] << endl;
	}
	return 0;
}

*/

