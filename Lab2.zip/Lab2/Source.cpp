#include <iostream>
using namespace std;

/*
void Display(int Array[][3])
{
	cout << "Your Entered Array is:\n";

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cout << Array[i][j] << " ";
		}
		cout << endl;
	}

	cout << endl;
}


void Find(int Array[][3], int Tar)
{
	bool Found = false;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			if (Array[i][j] == Tar)
			{
				cout << "Target Element is on the Index : [" << i << "] [" << j << "] .\n";
				Found = true;
				break;
			}
			else
			{
				continue;
			}
		}
	}

	if (!Found)
	{
		cout << "Sorry Not Found!!!\n";
	}
}

int main()
{

	cout << "Enter the numbers in the given matrix of 3x3:\n";
	int Array[3][3];
	int Target = 0;
	
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cin >> Array [i][j];
		}
	}

	cout << "Enter the Target Element: ";
	cin >> Target;

	Display(Array);
	Find(Array, Target);
	return 0;
}

*/

// Task 2


class Array
{
private:
	int LeftD = 0;
	int RightD = 0;
public:
	void Diagnols(int a[][3]);
	int getRight();
	int getLeft();
};

void Array::Diagnols(int a[][3])
{
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			if (i == j)
			{
				LeftD += a[i][j];
			}
		}
	}

	for (int i = 0; i < 3; i++)
	{
		for (int j = 2; j >= 0; j--)
		{
			if (i == j)
			{
				RightD += a[i][j];
			}
		}
	}
}

int Array::getLeft()
{
	return LeftD;
}

int Array::getRight()
{
	return RightD;
}

int main()
{
	cout << "Enter the numbers in a 3x3 Matrix: \n";
	int array[3][3];

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cin >> array[i][j];
		}
	}

	Array A;
	A.Diagnols(array);

	cout << "Sum of Left Diagnol is: " << A.getLeft() << ".\n";
	cout << "Sum of Right Diagnol is: " << A.getRight() << ".\n";
	return 0;
}


// Task 3

/*
void Display(int Array[][3])
{

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cout << Array[i][j] << " ";
		}
		cout << endl;
	}

	cout << endl;
}


void Find(int Array[][3])
{
	int row = 0;
	int col = 0;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			if (Array[i][j] == 0)
			{
				row = i;
				col = j;
				break;
			}
			else
			{
				continue;
			}
		}
	}

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			if (i == row)
			{
				Array[i][j] = 0;
			}
			if (j == col)
			{
				Array[i][j] = 0;
			}
		}
	}
}

int main()
{

	cout << "Enter the numbers in the given matrix of 3x3:\n";
	int Array[3][3];

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cin >> Array[i][j];
		}
	}


	cout << "Your Entered Array is:\n";

	Display(Array);
	Find(Array);


	cout << "Your Modified Array is:\n";
	Display(Array);
	return 0;
}
*


// Task 4

/*
int main()
{
	int sum = 0;
	int Array1[4][4];
	int Array2[4][4];
	int Resultant[4][4];
	cout << "Enter the numbers in a 3x4 Matrix 1: \n";

	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			cin >> Array1[i][j];
		}
	}

	cout << "Enter the numbers in a 4x3 Matrix 2: \n";

	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			cin >> Array2[i][j];
		}
	}

	cout << "Now I will Multiply Martrix 1 with Matrix 2\n";
	cout << "\nPROCESSING....\n\n";

	int add = 0;

	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			Resultant[i][j] = 0;
			for (int k = 0; k < 4; k++)
			{
				Resultant[i][j] += Array1[i][k] * Array2[k][j];
			}
		}
	}

	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			cout << Resultant[i][j] << " ";
		}
		cout << endl;
	}

	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			sum += Resultant[i][j];
		}
	}

	cout << "Sum of Matrix: " << sum << endl;
	return 0;
}


// Task 5
/*
template <class T>
T sum() {}

*/